import { useState } from 'react';
import { ChevronIcon } from './ChevronIcon.jsx';

// Tegel-knop zoals content.js' mkButton({ tick: false }) — hover-lift +
// wash-achtergrond, chevron rechts, JS-gedreven focus-ring (onsahFocusRing).
// Eigen, kleine kopie: mkButton zelf is een generiek onderdeel dat elders in
// content.js nog tientallen andere knoppen bedient en blijft dus vanilla.
export function TileButton({ label, onClick, tokens, style, disabled }) {
  const [hover, setHover] = useState(false);
  const [active, setActive] = useState(false);
  const [focused, setFocused] = useState(false);
  const T = tokens;
  return (
    <button
      type="button"
      aria-disabled={disabled ? 'true' : undefined}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        onClick(e);
      }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => {
        setHover(false);
        setActive(false);
      }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        width: '100%',
        padding: '10px 11px',
        borderRadius: 11,
        border: '1px solid ' + (hover ? 'transparent' : T.brand),
        background: hover ? T.brandWash : '#fff',
        color: T.ink,
        font: '600 13.5px/1.3 system-ui,-apple-system,sans-serif',
        textAlign: 'left',
        cursor: 'pointer',
        transition: 'transform .12s ease, box-shadow .12s ease, background .12s ease, border-color .12s ease',
        boxSizing: 'border-box',
        transform: active ? 'translateY(0)' : hover ? 'translateY(-1px)' : 'none',
        boxShadow: hover ? '0 4px 14px -6px rgba(32,20,15,.28)' : 'none',
        outline: focused ? '2px solid ' + T.brand : 'none',
        outlineOffset: 2,
        ...style,
        ...(disabled ? { opacity: 0.55, cursor: 'not-allowed' } : null),
      }}
    >
      <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
        {label}
      </span>
      <ChevronIcon size={14} style={{ width: 14, height: 14, color: hover ? T.brand : '#c7bfbc', flex: '0 0 auto', transition: 'color .12s ease' }} />
    </button>
  );
}
