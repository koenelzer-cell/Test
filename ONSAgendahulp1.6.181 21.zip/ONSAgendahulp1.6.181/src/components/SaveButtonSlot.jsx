import { TileButton } from './TileButton.jsx';

// Vervangt het Opslaan-knop-deel van content.js' showAppointmentReadyToSave.
// De terugknop, tekstregels en doorplannen-toggel blijven vanilla (gekoppeld
// aan het beheerscherm-configureerbare tekstsysteem, mkText) — alleen dit
// stuk is zuiver presentatie zonder die koppeling.
export function SaveButtonSlot({ tokens, disabled, onSave, showUursoortNote }) {
  return (
    <div>
      <TileButton label="Opslaan" onClick={onSave} tokens={tokens} disabled={disabled} />
      {showUursoortNote && (
        <div style={{ fontSize: 12, color: '#b3261e', margin: '6px 0 0', fontWeight: 700 }}>
          Let op: voeg nog een uursoort toe.
        </div>
      )}
    </div>
  );
}
