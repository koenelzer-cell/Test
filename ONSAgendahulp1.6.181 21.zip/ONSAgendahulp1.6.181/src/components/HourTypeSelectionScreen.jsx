import { BackButton } from './BackButton.jsx';
import { TileButton } from './TileButton.jsx';

// Vervangt de dubbele DOM-opbouw in content.js' showRegistrationHourTypeSelection
// (eerst "laden...", dan de async callback die vrijwel hetzelfde opnieuw bouwt).
// Eén component met een loading-prop i.p.v. die duplicatie.
export function HourTypeSelectionScreen({ title, loading, options, tokens, onBack, onPickOption }) {
  return (
    <div>
      <div style={{ fontWeight: 700, fontSize: 13, margin: '2px 0 4px' }}>{title}</div>
      <div style={{ marginBottom: 8 }}>
        <BackButton label="Terug" onClick={onBack} tokens={tokens} />
      </div>
      {loading ? null : !options.length ? (
        <div style={{ color: '#c62828', fontSize: 12 }}>Geen uursoorten gevonden</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {options.map((opt) => (
            <TileButton key={opt} label={opt} onClick={() => onPickOption(opt)} tokens={tokens} />
          ))}
        </div>
      )}
    </div>
  );
}
