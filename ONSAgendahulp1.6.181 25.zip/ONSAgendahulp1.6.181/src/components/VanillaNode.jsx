import { useEffect, useRef } from 'react';

// Plaatst een bestaand, door content.js gebouwd DOM-element in de React-boom.
// Bewust gebruikt voor de duurkeuze (mkDurationPicker/mkValuePicker): dat is
// ~250 regels fijn afgestelde logica met drie instelbare stijlen (schuifregelaar,
// uren+minuten, twee kolommen). Die naschrijven in React levert niets op en is
// juist de plek waar een regressie zou ontstaan — dus hergebruiken we hem.
export function VanillaNode({ node }) {
  const ref = useRef(null);
  useEffect(() => {
    const host = ref.current;
    if (!host || !node) return undefined;
    host.replaceChildren(node);
    return () => { try { host.replaceChildren(); } catch (e) {} };
  }, [node]);
  return <div ref={ref} />;
}
