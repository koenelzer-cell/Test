import { InfoScreen } from './InfoScreen.jsx';
import { ChoicesScreen } from './ChoicesScreen.jsx';
import { PickListScreen } from './PickListScreen.jsx';
import { NeedsPrereqsScreen } from './NeedsPrereqsScreen.jsx';
import { MessageScreen } from './MessageScreen.jsx';
import { DurationScreen } from './DurationScreen.jsx';
import { NavButton } from './NavButton.jsx';

// Eén ingang voor alle wizardschermen: content.js zegt wélk scherm het is
// (dezelfde namen als markScreen gebruikt) en levert de gegevens; hier wordt
// dat naar het bijbehorende component vertaald. Zo groeit de migratie
// scherm-voor-scherm zonder dat content.js van componentbestanden hoeft te weten.
export function WizardScreen({ name, props }) {
  const p = props || {};
  switch (name) {
    case 'infoScreen':
      return <InfoScreen {...p} />;
    case 'messageScreen':
      return <MessageScreen {...p} />;
    case 'choices':
      return (
        <ChoicesScreen
          {...p}
          extra={p.showSaveNav ? <div style={{ marginTop: 6 }}><NavButton label="Naar opslaan" onClick={p.onSaveNav} tokens={p.tokens} /></div> : null}
        />
      );
    case 'pickList':
      return <PickListScreen {...p} />;
    case 'needsPrereqs':
      return <NeedsPrereqsScreen {...p} />;
    case 'duration':
      return <DurationScreen {...p} />;
    default:
      return null;
  }
}
